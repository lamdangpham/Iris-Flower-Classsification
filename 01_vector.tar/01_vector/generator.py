import numpy as np
import os
from itertools import islice
import sys
import re
from natsort import natsorted, ns
from hypara import *
import random

class generator(object):

    def __init__(self, train_dir, eva_dir):  

        self.train_dir      = train_dir
        self.eva_dir        = eva_dir

        self.class_num      = hypara().class_num
        self.label_dict     = hypara().label_dict


    def get_single_file (self, file_num, data_dir): 
        file_list = self.get_file_list(data_dir)
        file_name     = file_list[file_num]
        file_open     = os.path.join(data_dir, file_name)
        o_data        = np.reshape(np.load(file_open)['x'], (1,-1))  # 128 --> 1x128
        return o_data, file_name

    def get_batch (self, batch_num, batch_size, is_mixup): # 10, 100 in 1000 files

        nImage = 0
        org_file_list = os.listdir(self.train_dir)
        file_list = []  #remove .file
        for nFile in range(0,len(org_file_list)):
            isHidden=re.match("\.",org_file_list[nFile])
            if (isHidden is None):
                file_list.append(org_file_list[nFile])
        file_num  = len(file_list)

        file_list = sorted(file_list)  #list contend all input files
        train_file_id  = np.random.RandomState(seed=42).permutation(file_num) # list contend all input files


        for ind in range(batch_num*batch_size, (batch_num+1)*batch_size):
            if ind >= file_num:
                mul = int(ind/file_num)
                ind = ind - mul*file_num
            # open file
            file_name = file_list[train_file_id[ind]]
            file_open = os.path.join(self.train_dir, file_name)
   
            #create label
            expectedClass = np.zeros([1, self.class_num])  # [0 0 0 0 0 0 0 ..]
            class_name = file_name.split('_')[0].split('-')[-1]
            nClass = self.label_dict[class_name]
            expectedClass[0,nClass] = 1               # [ 0 0 0 0 1 0 0 0 ..]

            #create data
            #fl_ob = np.reshape(np.load(file_open),(1,-1))  
            fl_ob = np.load(file_open)  
            one_vector = fl_ob['x']
            #print(np.shape(one_vector))
            #exit()
            if (nImage == 0):
               seq_x = one_vector
               seq_y = expectedClass
            else:            
               seq_x = np.concatenate((seq_x, one_vector), axis=0)  
               seq_y = np.concatenate((seq_y, expectedClass), axis=0)  
            nImage += 1
        #print(np.shape(seq_x)) # 100x128,    100xWxHx3
        #print(np.shape(seq_y)) # 100x10      100x10
        #exit()

        if is_mixup:
            o_data, o_label = self.mixup_aug(seq_x, seq_y, 0.4)
        else:
            o_data  = seq_x
            o_label = seq_y

        return o_data, o_label, nImage

    def get_batch_num(self, batch_size):

        org_file_list = os.listdir(self.train_dir)
        file_list = []  #remove .file
        for nFile in range(0,len(org_file_list)):
            isHidden=re.match("\.",org_file_list[nFile])
            if (isHidden is None):
                file_list.append(org_file_list[nFile])
        file_num  = len(file_list)
            
        return (file_num/batch_size) + 1
    
    def get_file_num(self, data_dir):
        return len(os.listdir(data_dir))

    def get_file_list(self, data_dir):
        file_list = []
        org_file_list = os.listdir(data_dir)
        for i in range(0,len(org_file_list)):
           isHidden=re.match("\.",org_file_list[i])
           if (isHidden is None):
              file_list.append(org_file_list[i].split('.npy')[0])
        #natsorted(file_list)
        file_list.sort()
        #print(file_list)
        #exit()
        return file_list

    #---- online mixup data augmentation
    def mixup_aug(self, i_data, i_label, beta=0.4):
        half_batch_size = round(np.shape(i_data)[0]/2)
        #print(half_batch_size, np.shape(i_data))

        x1  = i_data[:half_batch_size,:]
        x2  = i_data[half_batch_size:,:]

        y1  = i_label[:half_batch_size,:]
        y2  = i_label[half_batch_size:,:]

        # Beta distribution
        b   = np.random.beta(beta, beta, half_batch_size)
        X_b = b.reshape(half_batch_size, 1)
        y_b = b.reshape(half_batch_size, 1)

        xb_mix   = x1*X_b     + x2*(1-X_b)
        xb_mix_2 = x1*(1-X_b) + x2*X_b

        yb_mix   = y1*y_b     + y2*(1-y_b)
        yb_mix_2 = y1*(1-y_b) + y2*y_b

        # Uniform distribution
        l   = np.random.random(half_batch_size)
        X_l = l.reshape(half_batch_size, 1)
        y_l = l.reshape(half_batch_size, 1)

        xl_mix   = x1*X_l     + x2*(1-X_l)
        xl_mix_2 = x1*(1-X_l) + x2*X_l

        yl_mix   = y1* y_l    + y2 * (1-y_l)
        yl_mix_2 = y1*(1-y_l) + y2*y_l

        o_data     = np.concatenate((xb_mix,    x1,    xl_mix,    xb_mix_2,    x2,    xl_mix_2),    0)  # 300x128
        o_label    = np.concatenate((yb_mix,    y1,    yl_mix,    yb_mix_2,    y2,    yl_mix_2),    0)
        #o_data     = np.concatenate((xb_mix,    x1,    xb_mix_2,    x2),    0)
        #o_label    = np.concatenate((yb_mix,    y1,    yb_mix_2,    y2),    0)
        #o_data     = np.concatenate((xb_mix,    xl_mix,    xb_mix_2,    xl_mix_2),    0)
        #o_label    = np.concatenate((yb_mix,    yl_mix,    yb_mix_2,    yl_mix_2),    0)

        return o_data, o_label

