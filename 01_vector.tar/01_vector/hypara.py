import numpy as np
import os

class hypara(object):

    def __init__(self):

        #---- Create Label dic
        self.label_dict     = dict(setosa=0, versicolor=1, virginica=2)


        #---- Para for generator and training
        self.nS     = 4     #MobileNetV2

        self.eps           = np.spacing(1)
        self.batch_size    = 20
        self.start_batch   = 0
        self.learning_rate = 1e-3  #1e-4/cnn14, 
        self.is_aug        = False
        self.check_every   = 20
        self.class_num     = len(self.label_dict)
        self.epoch_num     = 500
