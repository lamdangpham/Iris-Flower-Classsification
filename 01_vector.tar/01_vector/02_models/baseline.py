
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input

from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Concatenate

from util import *

def baseline(nS, nClass):
   #----------------------------------------- input define
   input_shape = (nS)
   inputs = Input(shape=input_shape)

   #---------------------------------------- network architecture
   x = l_dense(inputs, den_unit=32)
   x = l_act(x, 'relu')
   x = l_drop(x, 0.1)

   x = l_dense(inputs, den_unit=64)
   x = l_act(x, 'relu')
   x = l_drop(x, 0.1)

   x = l_dense(x, den_unit=nClass)
   x = l_act(x, 'softmax', "output")

   #---output
   name='baseline'
   output = Model(inputs=inputs, outputs=x, name=name)

   return output
   

