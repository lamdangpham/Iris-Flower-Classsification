#---- general packages
import numpy as np
import os
import argparse
import math
import scipy.io
import re
import time
import datetime
import sys
import tensorflow as tf
from sklearn import datasets, svm, metrics

#----- generator
sys.path.append('./02_models/')
from baseline import *
from util import *
from generator import *
from hypara import *


#----- main
def main():
    print("\n ==================================================================== SETUP PARAMETERS...")
    print("-------- PARSER:")
    parser = init_argparse()
    args   = parser.parse_args()
    OUT_DIR          = args.out_dir
    IS_TRAINING      = args.is_training
    IS_TESTING       = args.is_testing
    IS_EXTRACTING    = args.is_extracting

    print("-------- Hyper parameters:")
    NS               = hypara().nS
    BATCH_SIZE       = hypara().batch_size
    START_BATCH      = hypara().start_batch
    LEARNING_RATE    = hypara().learning_rate
    IS_AUG           = hypara().is_aug
    CHECKPOINT_EVERY = hypara().check_every
    N_CLASS          = hypara().class_num
    NUM_EPOCHS       = hypara().epoch_num
    LABEL_DICT       = hypara().label_dict
    
    #Setting directory
    print("\n =============== Directory Setting...")
    stored_dir = os.path.abspath(os.path.join(os.path.curdir, OUT_DIR))
    print("+ Writing to {}\n".format(stored_dir))

    best_model_dir = os.path.join(stored_dir, "model")
    print("+ Best model Dir: {}\n".format(best_model_dir))
    if not os.path.exists(best_model_dir):
        os.makedirs(best_model_dir)
    best_model_file = os.path.join(best_model_dir, "best_model.h5")

    #Random seed
    tf.random.set_seed(0) #V2
    
    #----------------------------------------------------------------------- TENSOR FLOW SETTING
    #Instance model or reload an available model
    if os.path.isfile(best_model_file):
        model = tf.keras.models.load_model(best_model_file)
        with open(os.path.join(stored_dir,"train_acc_log.txt"), "a") as text_file:
            text_file.write("Latest model is loaded from: {} ...\n".format(best_model_dir))
    else:
        model=baseline(nS=NS, nClass=N_CLASS)
        with open(os.path.join(stored_dir,"train_acc_log.txt"), "a") as text_file:
            text_file.write("New model instance is created...\n")
    model.summary()

    ## initialize the optimizer and compile the model
    opt = tf.keras.optimizers.Adam(LEARNING_RATE)
    model.compile(loss=tf.keras.losses.kullback_leibler_divergence, optimizer=opt, metrics=["accuracy"])   

    test_threshold  = 0.1

    generator_ins   = generator(args.train_dir, args.eva_dir)  #instance a generator

    # for test
    n_valid         = generator_ins.get_file_num(generator_ins.eva_dir)
    batch_num       = int(generator_ins.get_batch_num(BATCH_SIZE))

    if IS_TRAINING == 'yes':
        for nEpoch in range(NUM_EPOCHS):
            for nBatchTrain in range(START_BATCH, batch_num):
                x_train_batch, y_train_batch, n_image = generator_ins.get_batch(nBatchTrain, BATCH_SIZE, IS_AUG) #  300x128, 300x10  
                #print(np.shape(x_train_batch), np.shape(y_train_batch))
                #exit()
                [train_loss, train_score] = model.train_on_batch(x_train_batch, y_train_batch, reset_metrics=True)  #one output

                if (nBatchTrain % CHECKPOINT_EVERY == 0):  
                    with open(os.path.join(stored_dir,"train_acc_log.txt"), "a") as text_file:
                        text_file.write("Epoch:{}, TRAIN SCORE:{}, TRAIN LOSS:{} \n".format(nEpoch, train_score, train_loss))

                    if(train_score >= test_threshold) and (IS_TESTING == 'yes') :   
                        file_valid_acc   = 0
                        fuse_matrix      = np.zeros([N_CLASS, N_CLASS])
                        valid_metric_reg = np.zeros(n_valid)
                        valid_metric_exp = np.zeros(n_valid)
                        
                        for nFileValid in range(0,n_valid):
                            x_valid_batch, valid_file_name = generator_ins.get_single_file(nFileValid, args.eva_dir)

                            #expected  
                            class_name = valid_file_name.split('_')[0].split('-')[-1]
                            valid_res_exp = LABEL_DICT[class_name]                                        

                            #recognized  
                            valid_end_output     = model.predict(x_valid_batch)
                            sum_valid_end_output = np.sum(valid_end_output, axis=0) #1xnClass
                            valid_res_reg        = np.argmax(sum_valid_end_output)
                            
                            #Compute acc
                            valid_metric_reg[nFileValid] = int(valid_res_reg)
                            valid_metric_exp[nFileValid] = int(valid_res_exp)
                        
                        #for sklearn metric
                        acc = metrics.classification_report(valid_metric_exp, valid_metric_reg)
                        cm  = metrics.confusion_matrix(valid_metric_exp, valid_metric_reg)
                        with open(os.path.join(stored_dir,"valid_acc_log.txt"), "a") as text_file_02:
                            text_file_02.write("========================== VALIDATING ==================================== \n\n")
                            text_file_02.write("On File Final Accuracy:\n")
                            text_file_02.write("{}%\n".format(acc))
                            text_file_02.write("{} \n".format(cm))
                            text_file_02.write("Save best model at Epoch: {}; \n".format(nEpoch))
                            text_file_02.write("========================================================================== \n\n")


def update_lr(model, epoch):
    if epoch >= 100:
        new_lr = 0.0001
        model.optimizer.lr.assign(new_lr)

def cus_loss(y_true, y_pred):
    return tf.reduce_mean(tf.square(y_true-y_pred))


def init_argparse():
    parser = argparse.ArgumentParser(
        usage="%(prog)s --out_dir XXX --dev_dir XXX --train_dir XXX --eva_dir XXX --test_dir XXX",
        description="Set directory of spectrogram of dev/train/eva/test sets" 
    )
    parser.add_argument(
        "--out_dir", required=True,
        help=' --outdir <output directory>'
    )
    parser.add_argument(
        "--train_dir", required=True,
        help=' --train_dir <train spectrogram directory>'
    )
    parser.add_argument(
        "--eva_dir", required=True,
        help=' --eva_dir <eva spectrogram directory>'
    )
    parser.add_argument(
        "--is_training", required=True,
        help=' --is_training <yes/no>'
    )
    parser.add_argument(
        "--is_testing", required=True,
        help=' --is_testing <yes/no>'
    )
    parser.add_argument(
        "--is_extracting", required=True,
        help=' --is_testing <yes/no>'
    )
    return parser


def focal_loss(gamma=2., alpha=4.):

    gamma = float(gamma)
    alpha = float(alpha)

    def focal_loss_fixed(y_true, y_pred):

        epsilon = 1.e-9
        y_true = tf.convert_to_tensor(y_true, tf.float32)
        y_pred = tf.convert_to_tensor(y_pred, tf.float32)

        model_out = tf.add(y_pred, epsilon)
        ce = tf.multiply(y_true, -tf.log(model_out))
        weight = tf.multiply(y_true, tf.pow(tf.subtract(1., model_out), gamma))
        fl = tf.multiply(alpha, tf.multiply(weight, ce))
        reduced_fl = tf.reduce_max(fl, axis=1)
        return tf.reduce_mean(reduced_fl)
    return focal_loss_fixed


if __name__ == "__main__":
    main()
